<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {
    public function __construct()
	{
        parent::__construct();
		$this->load->model('m_master');
	}

	public function index()
	{       
		$this->load->view('absen');
	}
	public function load_data()
	{
		$nik = $this->input->get('nik');
		$tgl = $this->input->get('tanggal');		
		// echo json_encode($tgl);
		$year = substr($tgl,2,2);
		$month = substr($tgl,5,2);
		$day = substr($tgl,8,2);
		$jam = substr($tgl,11,5);
		$id = $nik.$year.$month;
		// echo json_encode($jam);
		$str = ltrim($day, '0');
		$mstr = "m".$str;
		
		// echo json_encode($str);
		$dt_peg = $this->m_master->getData($nik);
		if (is_array($dt_peg) || is_object($dt_peg)){			
			foreach ($dt_peg as $key) {
				$jm = $key->shift_masuk;
				$jk = $key->shift_keluar;
			}
		}
		
		if($dt_peg !== null){
			if ($jam < $jm) {//-----------pagi
				$abs = $this->m_master->getAbsenLock($id);
				if ($abs == null) {
					$val = $this->m_master->getData($nik);
					foreach ($val as $value) {
						$insert = 	$this->m_master->insertAbsen($str, $tgl, $nik, $value->Nama, $value->Bagian, $value->Jabatan, $id, 'M');
						$hsl = $this->m_master->getAbsenLock($id);
					}
					$response = array('response' => "MASUK", 'data' => $hsl);
					echo json_encode($response);
				}else{
					foreach ($abs as $key) {
						if($key->$mstr == null){
							$val = $this->m_master->getData($nik);
							foreach ($val as $value) {
								$update =	$this->m_master->updateAbsen($str, $tgl, $nik, $value->Nama, $value->Bagian, $value->Jabatan, $id, 'M');
								$hsl = $this->m_master->getAbsenLock($id);
							}
							$response = array('response' => "MASUK 1", 'data' => $hsl);
							echo json_encode($response);
						}else{				
							$hsl = $this->m_master->getAbsenLock($id);
							$response = array('response' => "SUDAH", 'data' => $hsl);
							echo json_encode($response);
						}
					}
				}
			}elseif($jam < $jk && $jam > $jm){//------------telat
				$abs = $this->m_master->getAbsenLock($id);
				if ($abs == null) {
					$val = $this->m_master->getData($nik);
					foreach ($val as $value) {
						$insert = 	$this->m_master->insertAbsen($str, $tgl, $nik, $value->Nama, $value->Bagian, $value->Jabatan, $id, 'T');
					}
					$hsl = $this->m_master->getAbsenLock($id);
					$response = array('response' => "TERLAMBAT 1", 'data' => $hsl);
					echo json_encode($response);
				}else{
					foreach ($abs as $key) {
						if($key->$mstr == null){
							$val = $this->m_master->getData($nik);
							foreach ($val as $value) {
								$update =	$this->m_master->updateAbsen($str, $tgl, $nik, $value->Nama, $value->Bagian, $value->Jabatan, $id, 'T');
								$hsl = $this->m_master->getAbsenLock($id);
							}
							$response = array('response' => "TERLAMBAT 2", 'data' => $hsl);
							echo json_encode($response);
						}else{
							$val = $this->m_master->getData($nik);
							foreach ($val as $value) {
								$update =	$this->m_master->updateAbsenPulang($str, $tgl, $nik, $value->Nama, $value->Bagian, $value->Jabatan, $id);
								$hsl = $this->m_master->getAbsenLock($id);
							}
							$response = array('response' => "PULANG 1", 'data' => $hsl);
							echo json_encode($response);		
						}	
					}						
				}
			}else{				
				$hsl = $this->m_master->getAbsenLock($id);
				$response = array('response' => "SUDAH", 'data' => $hsl);
				echo json_encode($response);
			}
		}else{
			$hsl = $this->m_master->getAbsenLock($id);
			$response = array('response' => "DATA BELUM ADA", 'data'=> $hsl);
			echo json_encode($response);
		}		
	}
}
