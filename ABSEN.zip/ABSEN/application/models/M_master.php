<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_master extends CI_Model {

    public function getData($nik){
        $query = $this->db->query("SELECT * FROM t_m_peg a, t_m_shift b where a.shift = b.shift_nama and NIK = $nik ");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $value) {
                $data[] = $value;
            }
            return $data;
        }
    }
    public function getAbsenLock($id){
        $query = $this->db->query("SELECT * FROM t_absen_ck where Tanik = '$id' ");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $value) {
                $data[] = $value;
            }
            return $data;
        }
    }
    public function insertAbsen($str, $tgl, $nik, $nama, $bag, $jab, $id, $dt){
        $query = $this->db->query(" INSERT INTO t_absen_ck (TanggalX, NIK, Nama, Jabatan, Bagian, s$str, m$str, Tanik)
                                VALUES ('$tgl', '$nik', '$nama' , '$jab', '$bag', '$dt' ,'$tgl', '$id' )");
      return $query;
    }
    public function updateAbsen($str, $tgl, $nik, $nama, $bag, $jab, $id,$dt){
        $query = $this->db->query(" UPDATE t_absen_ck SET s$str = '$dt', m$str = '$tgl'
                                WHERE Tanik = $id ");
        return $query;
    }
    public function updateAbsenPulang($str, $tgl, $nik, $nama, $bag, $jab, $id){
        $query = $this->db->query(" UPDATE t_absen_ck SET p$str = '$tgl'
                                WHERE Tanik = '$id' ");
            return $query;
    }
}

