<!DOCTYPE html>
<html>
    <head>
        <title>ABSEN BABYLONISH GARMENT</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<link rel="icon" href="<?php echo base_url('assets/img/logo.png'); ?>" type="image/gif" sizes="16x16">
		<link href="https://fonts.googleapis.com/css?family=Teko&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


		<style>		
			.jam-digital-malasngoding {
				float:none;
			}
			h2{
				font-weight: bold;
				margin-top: 1em;
			}
			.kotak{
				float: left;
				margin-top: 1em;
				text-align: center;
				width: 2em;	
				font-size: 25px;	
				font-color:#424244;
				background-color: #92DFAE;
				border-radius:10px 10px;
			}
			.kotak1{
				float: left;
				margin-top: 1em;
				text-align: center;
				width: 3.5em;	
				font-size: 25px;	
				font-color:#424244;
				background-color: #92DFAE;
				border-radius:10px 10px;
			}
			.jam-digital-malasngoding p {
				color: #000;
				font-size: 30px;
				text-align: center;
				margin-top: 1em;

			}
			body{
				font-color:#424244;
				font-family: 'Teko', sans-serif;
				background: #67B26F;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to right, #4ca2cd, #67B26F);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to right, #4ca2cd, #67B26F); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			#nik{
				border-radius: 1em 1em;
				padding: 1em;
				font-size: 16px;
			}
		</style>
	</head>
    <body>
		<div class="container" >
			<div class="form-group float-right">			
				<img src="<?php echo base_url('assets/img/logo2.png'); ?>" height="100" width="100" style = 'margin-top:1em;'>
			</div>
			<div class="form-group float-left">			
				<!-- <img src="<?php echo base_url('assets/img/logo.png'); ?>" height="100" width="100" style = 'margin-top:1em;'> -->
				<h2>Babylonish Garment</h2>
			</div>
			
			<center>
			<div class="form-group">			
				<img src="<?php echo base_url('assets/img/scanner.png'); ?>" width="270px"  style = 'margin-top:6em;'>
				<h2>SCAN DISINI</h2>
			</div>
			</center>
		</div>
		<div class="container">
			<div class="col-md-12">
				<div class="col-md-6 col-md-offset-3 ">
					<input name="nik" class=" text-center col-md-12" type="text" id="nik" placeholder="-------------------- BARCODE --------------------" autofocus>
				</div>
				<div class="col-md-offset-2 col-md-3">			
						<input type="hidden" id="tanggal" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('Y-m-d H:i:s'); ?>">
						<div class="jam-digital-malasngoding">
							<div>
								<div class="kotak" id="jam"></div>
								<div class="kotak" id="menit"></div>							
								<div class="kotak" id="detik"></div>
							</div>
						</div>
				</div>
				<div class="col-md-offset-3 col-md-3">			
						<input type="hidden" id="tanggal" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('Y-m-d H:i:s'); ?>">
						<div class="jam-digital-malasngoding">
							<div>							
								<div class="kotak" id="day"></div>
								<div class="kotak1" id="month"></div>
								<div class="kotak" id="year"></div>
							</div>
						</div>
				</div>
			</div>
		</div>
			
<!-- -----------------MODAL--------------------------- -->
	<!-- Modal -->
		<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title"></h4>
					</div>
					<div class="modal-body" id="div1">
					</div>	
					<div class="modal-footer">
					</div>
				</div>
			</div>
		</div>
		<!-- --------------------modal--------------- -->
        <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		  <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
   		 <!-- Include all compiled plugins (below), or include individual files as needed -->
    	<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
		
		<script type="text/javascript">
			window.setTimeout("waktu()", 500);
		
			function waktu() {
				var waktu = new Date();
				var month = new Array();
				month[0] = "January";
				month[1] = "February";
				month[2] = "March";
				month[3] = "April";
				month[4] = "May";
				month[5] = "June";
				month[6] = "July";
				month[7] = "August";
				month[8] = "September";
				month[9] = "October";
				month[10] = "November";
				month[11] = "December";
				setTimeout("waktu()", 500);
				// document.getElementById("day").innerHTML = waktu.getoLocaleDateString();
				document.getElementById("jam").innerHTML = waktu.getHours();
				document.getElementById("menit").innerHTML = waktu.getMinutes();
				document.getElementById("detik").innerHTML = waktu.getSeconds();
				document.getElementById("year").innerHTML = waktu.getFullYear();
				document.getElementById("month").innerHTML = month[waktu.getMonth()];
				document.getElementById("day").innerHTML = waktu.getDate();
			}
		</script>
		<script type="text/javascript">
			function delay(callback, ms) {
				var timer = 0;
				return function() {
					var context = this, args = arguments;
					clearTimeout(timer);
					timer = setTimeout(function () {
					callback.apply(context, args);
					}, ms || 0);
				};
			}
				$("#nik").keyup(delay(function (){
            // function isi_otomatis(){
				var nik = $("#nik").val();
				var tgl = $("#tanggal").val();
				var jam = tgl.substr(11,5);	
				var hari = tgl.substr(8,2);
				var sts = parseInt(hari, 10);
				var ss = "s"+sts;
					// var timer = setTimeout(function() {
						$.ajax({
							url: 'index.php/master/load_data',
							data:"nik="+nik+"&tanggal="+tgl ,
							dataType : "JSON",
							type : "GET",
							success: function(data){	
								
							// console.log(data['data']);
								if (!$.trim(data['data'])){   
									// console.log(data['data']);
									// Add response in Modal body
									$('.modal-body').html();							
									// Display Modal
									$('#myModal').modal('show'); 														
									var element = document.getElementById("div1");													
									element.className = "text-center";			
									var para = document.createElement("h4");
									var oImg = document.createElement("img");											
									oImg.setAttribute('src', '<?php echo base_url('assets/img/info.png')  ?>');
									oImg.style.width = '100px';
									var para2 = document.createElement("h4");
									var node = document.createTextNode("MAAF ANDA BELUM BISA ABSEN");					
									var node2 = document.createTextNode(data['response']+", TANYAKAN PADA YANG BERSANGKUTAN");		
									
									para.appendChild(node);
									para2.appendChild(node2);
									element.appendChild(para);
									element.appendChild(oImg);
									element.appendChild(para2);
									setTimeout(function(){
										window.location.reload();								
									},3000);
								
									$('#nik').focus();
									$('#nik').val('');		
								}
								else{   
									// console.log(data['data']);
									// Add response in Modal body
									$('.modal-body').html();							
									// Display Modal
									$('#myModal').modal('show'); 														
									var element = document.getElementById("div1");													
									element.className = "text-center";			
									var para = document.createElement("h4");
									var oImg = document.createElement("img");											
									oImg.setAttribute('src', '<?php echo base_url('assets/img/img.svg')  ?>');
									oImg.style.width = '100px';
									var para2 = document.createElement("h4");
									var node = document.createTextNode(data['data'][0].Nama);					
									var node2 = document.createTextNode("ANDA "+data['response']+" ABSEN, JAM "+jam);		
									
									para.appendChild(node);
									para2.appendChild(node2);
									element.appendChild(para);
									element.appendChild(oImg);
									element.appendChild(para2);
									setTimeout(function(){
										window.location.reload();								
									},3000);
								
									$('#nik').focus();
									$('#nik').val('');									
								}
							}
						
						});
					// }, 700);
					$(this).data('timer', timer);
				},500));
			
               /*  $.ajax({
                    url: 'index.php/master/load_data',
                    data:"nik="+nik ,
					dataType : "JSON",
					type : "GET",
					success: function(data){	
						$.each(data[0],function(NamaKaryawan, Bagian, Jabatan){
							
							$('#nama').val(data[0].NamaKaryawan);
							$('#bagian').val(data[0].Bagian);
							$('#jabatan').val(data[0].Jabatan);
						});
					}
                }); */
				
			
			
			
			
				/* var txtNama = $("#nama").val();
						console.log(txtNama);
						if(txtNama != "")
						{
							//perform task
						} */
        </script>
    </body>
</html>