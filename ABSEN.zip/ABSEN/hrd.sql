-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2019 at 06:32 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrd`
--

-- Table structure for table `t_absen_ck`
--

CREATE TABLE `t_absen_ck` (
  `id_absen_ck` int(10) NOT NULL,
  `Tanggalx` varchar(20) DEFAULT NULL,
  `NIK` varchar(20) DEFAULT NULL,
  `Nama` varchar(20) DEFAULT NULL,
  `Departement` varchar(50) DEFAULT NULL,
  `Bagian` varchar(20) NOT NULL,
  `Jabatan` varchar(20) NOT NULL,
  `LAN` varchar(20) DEFAULT NULL,
  `kd_mandor` varchar(20) DEFAULT NULL,
  `mandor` varchar(20) DEFAULT NULL,
  `Hari` varchar(20) DEFAULT NULL,
  `s1` varchar(20) DEFAULT NULL,
  `m1` varchar(20) DEFAULT NULL,
  `p1` varchar(20) DEFAULT NULL,
  `s2` varchar(20) DEFAULT NULL,
  `m2` varchar(20) DEFAULT NULL,
  `p2` varchar(20) DEFAULT NULL,
  `s3` varchar(20) DEFAULT NULL,
  `m3` datetime(6) DEFAULT NULL,
  `p3` datetime(6) DEFAULT NULL,
  `s4` varchar(20) DEFAULT NULL,
  `m4` datetime(6) DEFAULT NULL,
  `p4` datetime(6) DEFAULT NULL,
  `s5` varchar(20) DEFAULT NULL,
  `m5` datetime(6) DEFAULT NULL,
  `p5` datetime(6) DEFAULT NULL,
  `s6` varchar(20) DEFAULT NULL,
  `m6` datetime(6) DEFAULT NULL,
  `p6` datetime(6) DEFAULT NULL,
  `s7` varchar(20) DEFAULT NULL,
  `m7` varchar(20) DEFAULT NULL,
  `p7` varchar(20) DEFAULT NULL,
  `s8` varchar(20) DEFAULT NULL,
  `m8` varchar(20) DEFAULT NULL,
  `p8` varchar(20) DEFAULT NULL,
  `s9` varchar(20) DEFAULT NULL,
  `m9` datetime(6) DEFAULT NULL,
  `p9` datetime(6) DEFAULT NULL,
  `s10` varchar(20) DEFAULT NULL,
  `m10` datetime(6) DEFAULT NULL,
  `p10` datetime(6) DEFAULT NULL,
  `s11` varchar(20) DEFAULT NULL,
  `m11` datetime(6) DEFAULT NULL,
  `p11` datetime(6) DEFAULT NULL,
  `s12` varchar(20) DEFAULT NULL,
  `m12` datetime(6) DEFAULT NULL,
  `p12` datetime(6) DEFAULT NULL,
  `s13` varchar(20) DEFAULT NULL,
  `m13` datetime(6) DEFAULT NULL,
  `p13` datetime(6) DEFAULT NULL,
  `s14` varchar(20) DEFAULT NULL,
  `m14` datetime(6) DEFAULT NULL,
  `p14` datetime(6) DEFAULT NULL,
  `s15` varchar(20) DEFAULT NULL,
  `m15` datetime(6) DEFAULT NULL,
  `p15` datetime(6) DEFAULT NULL,
  `s16` varchar(20) DEFAULT NULL,
  `m16` datetime(6) DEFAULT NULL,
  `p16` datetime(6) DEFAULT NULL,
  `s17` varchar(20) DEFAULT NULL,
  `m17` datetime(6) DEFAULT NULL,
  `p17` datetime(6) DEFAULT NULL,
  `s18` varchar(20) DEFAULT NULL,
  `m18` datetime(6) DEFAULT NULL,
  `p18` datetime(6) DEFAULT NULL,
  `s19` varchar(20) DEFAULT NULL,
  `m19` datetime(6) DEFAULT NULL,
  `p19` datetime(6) DEFAULT NULL,
  `s20` varchar(20) DEFAULT NULL,
  `m20` datetime(6) DEFAULT NULL,
  `p20` datetime(6) DEFAULT NULL,
  `s21` varchar(20) DEFAULT NULL,
  `m21` datetime(6) DEFAULT NULL,
  `p21` datetime(6) DEFAULT NULL,
  `s22` varchar(20) DEFAULT NULL,
  `m22` datetime(6) DEFAULT NULL,
  `p22` datetime(6) DEFAULT NULL,
  `s23` varchar(20) DEFAULT NULL,
  `m23` datetime(6) DEFAULT NULL,
  `p23` datetime(6) DEFAULT NULL,
  `s24` varchar(20) DEFAULT NULL,
  `m24` datetime(6) DEFAULT NULL,
  `p24` datetime(6) DEFAULT NULL,
  `s25` varchar(20) DEFAULT NULL,
  `m25` datetime(6) DEFAULT NULL,
  `p25` datetime(6) DEFAULT NULL,
  `s26` varchar(20) DEFAULT NULL,
  `m26` datetime(6) DEFAULT NULL,
  `p26` datetime(6) DEFAULT NULL,
  `s27` varchar(20) DEFAULT NULL,
  `m27` datetime(6) DEFAULT NULL,
  `p27` datetime(6) DEFAULT NULL,
  `s28` varchar(20) DEFAULT NULL,
  `m28` datetime(6) DEFAULT NULL,
  `p28` datetime(6) DEFAULT NULL,
  `s29` varchar(20) DEFAULT NULL,
  `m29` datetime(6) DEFAULT NULL,
  `p29` datetime(6) DEFAULT NULL,
  `s30` varchar(20) DEFAULT NULL,
  `m30` datetime(6) DEFAULT NULL,
  `p30` datetime(6) DEFAULT NULL,
  `s31` varchar(20) DEFAULT NULL,
  `m31` datetime(6) DEFAULT NULL,
  `p31` datetime(6) DEFAULT NULL,
  `Tanik` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_m_peg`
--

CREATE TABLE `t_m_peg` (
  `id_pegawai` int(10) NOT NULL,
  `NIK` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Nama` varchar(34) CHARACTER SET utf8 DEFAULT NULL,
  `TglMasuk` varchar(30) DEFAULT NULL,
  `TglKeluar` datetime DEFAULT NULL,
  `Bagian` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `JenisKelamin` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `TempatLahir` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `TglLahir` varchar(30) DEFAULT NULL,
  `Alamat` varchar(73) CHARACTER SET utf8 DEFAULT NULL,
  `NoTelp` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `Agama` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
  `Pendidikan` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `Departement` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Jabatan` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Mesin` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Status` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Keterangan` text CHARACTER SET utf8,
  `shift` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `t_m_peg`
--

INSERT INTO `t_m_peg` (`id_pegawai`, `NIK`, `Nama`, `TglMasuk`, `TglKeluar`, `Bagian`, `JenisKelamin`, `TempatLahir`, `TglLahir`, `Alamat`, `NoTelp`, `Agama`, `Pendidikan`, `Departement`, `Jabatan`, `Mesin`, `Status`, `Keterangan`, `shift`) VALUES
(1, '19020025', 'BIMA ADWIYANA', NULL, NULL, 'DEPT. IT','IT', 'LAKI - LAKI', 'BOJONEGORO', '31/05/1995', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'SHIFT1');

-- --------------------------------------------------------

--
-- Table structure for table `t_m_shift`
--

CREATE TABLE `t_m_shift` (
  `shift_id` int(5) NOT NULL,
  `shift_nama` varchar(50) NOT NULL,
  `shift_masuk` varchar(50) NOT NULL,
  `shift_keluar` varchar(50) NOT NULL,
  `shift_ket` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_m_shift`
--

INSERT INTO `t_m_shift` (`shift_id`, `shift_nama`, `shift_masuk`, `shift_keluar`, `shift_ket`) VALUES
(1, 'SHIFT1', '07:31', '17:00', 'jam 7:30 pagi sampai jam 5 sore'),
(2, 'SHIFT2', '10:00', '19:30', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `organization`
--
-- Indexes for table `t_absen_ck`
--
ALTER TABLE `t_absen_ck`
  ADD PRIMARY KEY (`id_absen_ck`);

--
-- Indexes for table `t_m_peg`
--
ALTER TABLE `t_m_peg`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `t_m_shift`
--
ALTER TABLE `t_m_shift`
  ADD PRIMARY KEY (`shift_id`);

--
-- AUTO_INCREMENT for dumped tables
--

-- AUTO_INCREMENT for table `t_absen_ck`
--
ALTER TABLE `t_absen_ck`
  MODIFY `id_absen_ck` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t_m_peg`
--
ALTER TABLE `t_m_peg`
  MODIFY `id_pegawai` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_m_shift`
--
ALTER TABLE `t_m_shift`
  MODIFY `shift_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
